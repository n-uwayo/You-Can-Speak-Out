import React from 'react'

const Register = () => {
  return (
    <div>Register hgjksmzmxdjIHSAGZCXHJK</div>
  )
}

export default Register